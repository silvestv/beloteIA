/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beloteia;

/**
 *
 * @author Victor
 */
public class Deck {
    
    Carte deck[] = new Carte[32];        

    
    public Deck(){
    
    initPaquet();
    
   
    
    
    
        
    }

    /*public String randomAtout(){
        
    }*/
 
    
    private String initPaquet(){
        
    String couleur[] = {"Coeur", "Trèfle", "Pique", "Carreau"};
    String rang[] = {"7","8","9","10","Valet","Reine","Roi","As"};
        
     int r = (int)(Math.random()*4);
     String atout = couleur[r];
    
        for(int i=0; i<4; i++){
            
            for(int j=0; j<8; j++){
                 
                if (couleur[i].equals(atout))
                    deck[j+8*i] = new CarteAtout(rang[j], couleur[i]);
                
                else
                    deck[j+8*i] = new CarteReguliere(rang[j], couleur[i]);
                
                System.out.println(deck[j+8*i].getRangCarte()+deck[j+8*i].getCouleurCarte()+"vaut : "+deck[j+8*i].getValeur());
            }
        }
        System.out.println(atout);
    return atout;
    }
    
}


