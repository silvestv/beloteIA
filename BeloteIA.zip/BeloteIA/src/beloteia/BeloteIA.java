/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beloteia;

/**
 *
 * @author Victor
 */
public class BeloteIA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here7
        
        
        
        /*CarteAtout c1 = new CarteAtout("9", "Coeur");
        CarteReguliere c2 = new CarteReguliere("Valet", "Pique");
  
        System.out.println(c1.getValeur());
        System.out.println(c2.getValeur());*/
        
        Deck d = new Deck();
    }
    
}
